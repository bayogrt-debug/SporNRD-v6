# SporNRD — Belge Doğrulama Sistemi İşleyiş ve Güvenlik Kuralları

## Amaç ve temel ayrım

- **Belge Okuma:** Görüntüden yazı, barkod veya karekod çıkarma. Tek başına sahicilik kanıtı değildir.
- **Otomatik Ön Kontrol:** Alan/tarih/kimlik tutarlılığını kontrol etme. Resmî doğrulama değildir.
- **Resmî Doğrulama:** Yetkili belge düzenleyici kaynak tarafından belge varlığı, iptal/askı/geçerlilik, sahibi ve kapsamı teyit edilmiş sonucu güvenli sunucuda alma; gerekirse doğrulanmış sayısal imzayı doğrulama.
- **Yeşil doğrulama tiki yalnız resmî doğrulama için gösterilir.** Bir kullanıcı tarafından yazılan ad, numara, barkod veya yüklenen fotoğraf hiçbir zaman tek başına bu tiki oluşturamaz.

## Kapsam

Bireysel/Sporcu, Eğitmen/Antrenör ve İşletme/Kurum profilleri için: lisans, antrenörlük belgesi, kademe, vize, diploma, eğitim sertifikası, kulüp/tesis/kurum ruhsatı ve faaliyet belgeleri.

## İş akışı

1. Kişi tür, kaynak, branş, kademe/sınıf, düzenleyen kurum, belge numarası/barkodu, belge tarihi, geçerlilik tarihi ve belge sahibini girer. Dosya ekleyebilir.
2. Sistem biçim, dosya sınırı, tarihler, zorunlu alanlar, belge sahibi/profil kimliği tutarlılığını otomatik kontrol eder; farklı bilgileri incelemeye yönlendirir.
3. Varsa tarayıcı `BarcodeDetector` ile QR varlığı okunmaya çalışılır. OCR ve QR okumak, belgenin gerçekliğinin doğrulanması değildir.
4. **Canlı sistemde** varsa izinli e-Devlet/GSB/federasyon/kurum entegrasyonu veya güvenli sayısal imza denetimiyle belge resmî kaynaktan doğrulanır; kaynak sonucu, belge sahibi, numarası, branşı, kademe ve geçerlilik kontrol edilir.
5. Olumlu resmî doğrulama sonucuna yeşil tik; uyuşmazlık, iptal veya kaynağa erişilememe durumunda uygun bekleme/inceleme durumu verilir. Çevrimdışı demo yalnız 2. adımı gerçekleştirir.
6. İşlemde kullanılan belge fotoğrafı/PDF dosyası kalıcı depoya yazılmaz ve işlem tamamlandığında geçici kopyaları temizlenir. İleride kullanılan sunucu/kuyruk/önbellek/yedekler de saklama-imha tasarımına dahil edilir.
7. Yetkili kaynağın teyit ettiği belgenin adı/türü, branş/kademe, maskelenmiş numara, doğrulama kaynağı ve zamanı, geçerlilik durumu, kanıt referansı, son tekrar kontrol tarihi ayrı özel kayıtta tutulur.
8. Belge geçerliliği dolunca veya resmî kaynak iptal/vize kaybı bildirince yeşil tik kaldırılır ve tekrar kontrol gerekir.

## Durumlar

| Durum | Koşul | Gösterim |
|---|---|---|
| Bilgi Eksik | Zorunlu doğrulama alanları yok | Uyarı; tekrar doldur |
| Ön Kontrol Başarılı | Yerel veriler birbiriyle tutarlı | Mor; resmî kaynak bekleniyor |
| İnceleme Gerekli | Tarih/isim/branş/kademe çelişkisi | Uyarı, inceleme |
| Süresi Doldu | Geçerlilik tarihi geçmiş | Kırmızı; tekrar doğrula |
| Resmen Doğrulandı | Yetkili sunucunun doğrulanmış kaynak sonucu | **Yeşil tik** |
| Doğrulanamadı | Yetkili kaynağın olumsuz sonucu | Uyarı; neden |
| Kaynak Erişilemedi | Sorgulama yapılamadı | Beklemede; yeşil tik yok |

## Yetki ve kanıt politikası

- Doğrulama kararı istemcide (Acode/JavaScript/localStorage) verilmez. İleride güvenli sunucuda, kurumsal kaynaklara izinli ve kimliği doğrulanmış entegrasyonlar ile verilmelidir.
- Bir belge üzerindeki imza görüntüsü, logo, mühür, QR veya numara **kaynak onayı değildir**.
- Resmî sorgulama servisi kişinin TC kimlik numarası gibi ek alanlar isteyebilir. Bu veriler yalnız hukuki dayanak, aydınlatma ve gerekli teknik/idari korumalar sağlandığında işlenebilir.
- Yetki: sadece profil sahibi kendi belgesini görebilir; resmî inceleme yetkisi SporNRD'nin belirlenmiş, denetlenebilir görevlilerindedir. Her kaynağa en az ayrı erişim izni gerekir.
- Bir belgeden gelen doğrulama sonucu, bütün profilin kurumsal kimliğini otomatik olarak doğrulamaz; belgeye özgü gösterilir.
- Başkasına ait belgeler ve reşit olmayan kişilerin belgeleri için yetki ve veli/vasi denetimleri gerekir.
- Şüpheli yükleme/dosyalar otomatik reddedilebilir veya incelemeye alınabilir; otomatik yeşil tik verilmez.
- Belge dosyaları işlem dışında saklanmaz; doğrulama metadata ve silme işlem kayıtları ilgili hukuki saklama-imha politikasına göre tutulur.

## Acode V7.10.62 sınırları

- Çalışır: belge formları, kaynak seçimi, otomatik tarih/tür/veren/numara/sahip tutarlılığı, bellek içi görsel/PDF dosya kontrolü, QR varlığı denemesi (tarayıcı destekliyorsa), geçerlilik durumu, eski dosya eklerini temizleme.
- **Çalışmıyor / entegre edilmedi:** e-Devlet/GSB resmî sistemlerine yetkili otomatik sorgulama, imza zincirinin kriptografik doğrulanması, sunucu tarafı doğrulama, dış servis sonucu, gerçek yeşil tik.
- Geçerli resmî belge veya TC kimlik numarası bu çevrimdışı demo uygulamasına girilmemelidir.

## Resmî bilgi kaynakları

- e-Devlet Barkodlu Belge Doğrulama: https://www.turkiye.gov.tr/belge-dogrulama
- GSB Elektronik Belge Yönetim Sistemi Evrak Doğrulama: https://www.turkiye.gov.tr/gsb-ebys
- GSB antrenör belgelerinde e-dönüşüm: https://sporegitim.gsb.gov.tr/HaberDetaylari/1/1001/270653/antrenor-belgelerinde-e-donusum-basliyor.aspx
- KVKK imha ve silme: https://www.kvkk.gov.tr/Icerik/5441/KISISEL-VERILERIN-SILINMESI-YOK-EDILMESI-VEYA-ANONIM-HALE-GETIRILMESI-HAKKINDA-YONETMELIK


## V7.10.64 bilgi giriş konumları

- Eğitmen: Profili Düzenle → Eğitim ve Sertifikalar → Antrenörlük Belgeleri. Eski 06. Belge klasörü kaldırıldı.
- Sporcu: Profili Düzenle → Eğitim Bilgileri → Sertifikalar. Lisans bilgileri aynı belge kaydında.
- Kurum: Profili Düzenle → Kurum Bilgileri → Kurumsal Belgeler.
- QR görseli / doğrulama kodu alıcısı belge formunda Kaydet öncesinde. Desteklenen tarayıcılarda QR okuma denemesi yapılır; kaynak teyidi olmadan otomatik yeşil tik verilmez.
- Kayıtlı belge dosyaları kalıcı depoda tutulmaz.
