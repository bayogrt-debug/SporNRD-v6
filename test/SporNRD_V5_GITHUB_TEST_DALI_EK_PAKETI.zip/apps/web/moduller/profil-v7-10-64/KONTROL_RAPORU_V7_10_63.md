# SporNRD V7.10.63 — Uçtan Uca İşleyiş Denetimi

**Denetim tarihi:** 16 Kasım 2026  
**Temel sürüm:** V7.10.62  
**Kapsam:** Hesap oluşturma, demo doğrulama, oturum, profil türleri, Kurslar, ilan/başvuru/kabul, demo ödeme, QR ve kod doğrulaması, satış/hak ediş raporları, fatura bilgi hazırlığı, iptal/iade/itiraz senaryoları.

> Bu belge çalışan **çevrimdışı Acode prototipinin** kontrol raporudur. Testler gerçek ödeme, e-Fatura/e-Arşiv, SMS, e-posta veya çok cihazlı eş zamanlı işlemleri doğrulamaz.

## 1. Uygulanan düzeltmeler

1. **Hizmet veren raporu yetkisi** — Eğitmen/kurum artık raporda yalnız kendi kurslarına ait kayıtları görür. CSV dışa aktarımı da kendi satışlarıyla sınırlıdır; başka profillerin kayıtları ve tüm hesap verileri dışa aktarılamaz.
2. **Yanlış yönetici yetkileri** — Hizmet veren panelinden tüm verileri silme, herkesin hesabını JSON olarak dışa aktarma ve SporNRD genel komisyon oranlarını değiştirme erişimi kaldırıldı. Bu işlemler için canlı sistemde ayrı bir SporNRD yönetim rolü gerekecek.
3. **QR bilet erişimi** — QR/kayıt kodu bileti yalnız ilgili satın alma işlemini yapan profil tarafından açılabilir. Başka profilin `data-action` ile bilet açması da engellendi.
4. **Satış anı bilgisi koruması** — Ödeme alınmış demo sipariş için alıcı/hizmet veren bilgileri, kurs adı/branşı/ders programı/fiyatı ve indirim tutarı satış anında ayrı kaydedilir. İlanın daha sonra değiştirilmesi önceki işlem özetini değiştirmez.
5. **Faturalandırma hazırlığı** — Alıcı ve hizmet verene özel “Fatura / İşlem Bilgisi” ekranı eklendi. Belge eksikliği kontrol edilir. **Bu ekran fatura düzenlemez, fatura numarası üretmez ve resmî belge yerine geçmez.**
6. **Form sonrası değişikliklere karşı kontrol** — Kursun durdurulması, süresinin bitmesi, ön kayıt onayının değişmesi ve kontenjanın dolması gibi durumlar başvuru/ödeme kesinleşirken tekrar kontrol edilir.
7. **Fiyat ve koşul değişikliği** — Satın alma onay ekranı açıkken kurs fiyatı, ders programı, başlangıç/bitiş tarihi, onay zorunluluğu veya kupon tutarı değişirse eski onayla işlem tamamlanmaz. Yeniden inceleme/onay gerekir.
8. **Yinelenen satın alma** — Aynı profil ve aynı kursiyer adına aynı ayda birden fazla aktif demo satışın yanlışlıkla oluşturulması engellenir. Aynı hesaptan farklı kursiyerler için kayıt yapılabilir.
9. **Başvuru akışı** — Ön kayıt, hizmet verenin onayı veya ret/bekleme listesi kararından sonra alıcının yerel mesajına karar bildirimi kaydedilir. Süresi dolan/durdurulan kurs başvurusu onaylanamaz.
10. **Süresi dolan ilan** — Tarihi düzeltilmeden yeniden yayımlanamaz; ilan sahibi önce Kurs Düzenle ile tarihleri güncellemelidir.
11. **QR ve kod** — Çevrimdışı bilet kodları cihazdaki eski kodlarla çakışmayacak şekilde üretilir. Kod tekrar doğrulanamaz; hizmet verenin kurs sahipliği kontrolü korunur.
12. **İade ve itiraz** — QR öncesi ve sonrası iptal/iade/itiraz başvurusu eklenmiştir. Talep, otomatik para iadesi sayılmaz. Hizmet veren inceleyebilir ve yanıt verebilir; değerlendirme kaydı, hizmet veren/alan mesajlarıyla ilişkilidir. Açık itiraz bulunduğunda yeni QR doğrulaması veya demo hak ediş aktarımı yapılmaz. Resmî mutabakat/gerçek iade hâlâ canlı altyapıda ele alınmalıdır.
13. **Denetim izi** — Satış, QR, demo hak ediş, ön kayıt iptali, başvuru kararı, fiyat değişikliği, ilan durdurma/yeniden yayımlama, iade talebi ve hizmet veren yanıtı için zamanlı işlem kayıtları tutulur.

## 2. Test edilen senaryolar

| Alan | Senaryo | Sonuç |
| --- | --- | --- |
| Hesap | 3 profil türünde kayıt, demo e-posta doğrulama ve giriş | Geçti |
| Hesap | İlk girişte geçici şifre değiştirme ve profil oluşturma | Geçti |
| Profil | Sporcu, eğitmen, kurum giriş ekranları | Geçti |
| Kurslar | Sporcu ön kayıt → antrenör kabul → satın alma | Geçti |
| Kurslar | Antrenörün kuruma ait kursu doğrudan satın alması | Geçti |
| Satış | Satış anındaki fiyat/ilan bilgisinin kaydedilmesi | Geçti |
| Satış | İlanın fiyatı sonradan değiştiğinde eski satışın değişmemesi | Geçti |
| Satış | Ödeme onayı sırasında fiyat değişirse yeniden onay istemesi | Geçti |
| Kurslar | Aynı kursiyer için aktif yinelenen başvuru | Engellendi |
| Kurslar | Süresi dolmuş veya taslak ilana başvuru | Engellendi |
| Kurslar | Süresi dolmuş ilanı tarih yenilemeden yayımlama | Engellendi |
| QR | Yetkisiz hizmet verenin QR/kod doğrulaması | Engellendi |
| QR | Aynı QR/kodun ikinci kez kullanılması | Engellendi |
| QR | Yetkili hizmet verenin QR doğrulaması → finansal özet | Geçti |
| Finans | QR sonrasında tek demo hak ediş kaydı | Geçti |
| İade | Hizmet alandan talep, hizmet verenden yanıt | Geçti |
| İade | İtiraz sırasında QR/finansal aktarım yapılmaması | Geçti |
| Gizlilik | Başka profilin QR bileti/fatura bilgi ekranına erişimi | Engellendi |
| Rapor | Hizmet verenin yalnız kendi kurslarının kayıtlarını görmesi | Geçti |
| Yönetim | Hizmet verenin genel komisyon/JSON/sıfırlama kontrollerinin olmaması | Geçti |
| JavaScript | Sözdizimi ve senaryo testlerinde tarayıcı hatası | Hata görülmedi |
| ZIP | Dosya ve arşiv bütünlük kontrolü | Geçti |

**Test notu:** Hesap oluşturma işlemi güvenli olmayan test önizleme ortamında şifre özetleme fonksiyonu yalnız test için taklit edilerek sınandı. Gerçek uygulamadaki PBKDF2 kodu değiştirilmedi. Android/Acode cihaz testi ayrıca gereklidir.

## 3. Canlıya geçişten önce zorunlu kalanlar

### Kritik (sunucu ve ödeme altyapısı olmadan çözülemez)

- **Sunucu oturumu ve rol kontrolü:** Çevrimdışı localStorage ve istemci tarafı düğme kontrolü gerçek yetkilendirme sayılmaz. Hesap, kurum çalışanı, şube, eğitmen ve çocuk/veli yetkileri sunucuda uygulanmalı.
- **Gerçek ödeme doğrulaması:** Kredi kartı, nakit ve IBAN işlemleri hâlâ simüledir. Ödeme kuruluşu teyidi ve banka mutabakatı olmadan “ödeme alındı” veya “aktarıldı” durumu üretim ortamında yazılamaz.
- **e-Fatura / e-Arşiv:** Hizmet satışının faturasını hangi vergi mükellefinin keseceği, SporNRD aracılık/komisyon hizmetinin faturası, KDV ve iptal-iade belgeleri mali müşavir ve hukuk uzmanıyla kesinleştirilmeli; yetkili GİB entegrasyonu kurulmalı.
- **İade mutabakatı:** İade talepleri bu sürümde yalnız demo inceleme kaydı oluşturuyor. Finansal iade ve gerektiğinde daha önce aktarılmış hak edişin mutabakatı gerçek ödeme/operasyon sistemiyle yönetilmeli.
- **Tek kullanımlık güvenli QR:** Yerel statik QR kod, canlı sistem için yeterli güvenlik kanıtı değildir. Sunucu tarafından üretilen ve süre/nonce/oturum/rol kontrolleriyle doğrulanan işlem kodu gerekir.
- **Eş zamanlı kontenjan:** Birden fazla cihazdan aynı kursa eş zamanlı satın alma, yalnız yerel veriye bakılarak güvenli sınırlandırılamaz; atomik veri tabanı işlemi gerekir.

### İş/ürün kuralları netleştirilmeli

- **Fiyatlandırma birimi:** “Aylık fiyat” varsayımı özel ders, tek seans, kamp ve paketlerin tamamına uymaz. Kurs formunda birim (seans, aylık, paket, toplam) ve buna bağlı sözleşme/ödeme modeli ayrıca belirlenmeli.
- **Kursiyer uygunluğu:** Yaş aralığı ve veli adı demo formunda denetleniyor; resmî yaş, veli yetkisi, güvenlik ve kuruma özel katılım şartları doğrulanmıyor.
- **Kurs uygulaması:** Haftalık derslerin gerçekleşmesi eğitim sağlayıcıya ait kalır. Platformda QR yalnız işlem/erişim doğrulaması olarak ele alınmalı; eğitimsel tamamlanma kanıtı olarak sunulmamalı.
- **Eski satış kayıtları:** V7.10.63 öncesi satışlarda anlık fatura/ilan özeti kaydı bulunmayabilir. Sonradan gösterilen güncel profil bilgileri geçmişin kesin kanıtı sayılmamalıdır.
- **Bildirimler:** Profil içi mesajlar cihazdaki demo kayıtlarıdır. Dış cihazlara iletim, okundu/teslim edildi garantisi, zamanlanmış görevler ve üyelik bildirimleri ayrı altyapı ister.
- **KVKK ve saklama:** Kayıt, fatura adresi, çocuk/veli ve belge doğrulama verileri için veri minimizasyonu, saklama-imha, erişim ve aydınlatma kuralları uygulanmalı.

### Denetim sınırları

Bu inceleme tüm dünyadaki mümkün olan her olayı, Acode'un bütün Android sürümlerini veya gerçek kullanıcılardaki tüm ağ ve ödeme sorunlarını kapsamaz. Yukarıdaki kod ve tarayıcı senaryoları geçmiştir; canlı işlem güvenliği ve mevzuata uygunluk yalnızca bu testlerle teyit edilemez.

## 4. Faturalandırma için dış kaynak

- Gelir İdaresi Başkanlığı — e-Fatura ve e-Arşiv Fatura açıklamaları: https://gib.gov.tr ve https://cdn.gib.gov.tr/api/gibportal-file/file/getFileResources?objectKey=arsiv%2Fyardim-kaynaklar%2Finfografikler%2Fpdfs%2Fe_arsiv_fatura.pdf

**Önerilen sonraki çalışma:** Gerçek ödeme kuruluşu ve faturalandırma entegrasyonuna geçmeden önce hizmet verenin hukuki kimliği, alıcı türü, fatura kesen taraf, fiyatlandırma birimi ve iptal/iade kuralları bir sözleşme/veri şemasında kesinleştirilmelidir.
