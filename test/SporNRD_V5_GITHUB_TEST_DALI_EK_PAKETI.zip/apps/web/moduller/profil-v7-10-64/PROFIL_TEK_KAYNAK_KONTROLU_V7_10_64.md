# SporNRD V7.10.64 — Profil Düzenleme Tek-Kaynak Denetimi

## Kapsam ve yaklaşım

V7.10.63 tam Acode uygulamasından hareketle Bireysel/Sporcu, Eğitmen/Antrenör ve İşletme/Kurum profillerinin `Profili Düzenle` klasörleri tek tek karşılaştırıldı. Aynı verinin farklı formlarda tekrar tekrar istenmesi azaltıldı. Tamamen farklı işlemler (kimlik ve profil adı, spor branşı ve mesleki görev, kurs ve belge, ödeme ve fatura gibi) birleştirilmedi. Mevcut `p.data`, hesap-özel bilgi ve `spDocuments` kaynakları korundu.

### Tek kaynak haritası

| Bilgi / işlem | Giriş / kayıt merkezi | Diğer yerde görünümü |
|---|---|---|
| Resmî ad/soyad, doğum, veli | Kişisel Bilgiler → Kimlik | Diğer alanlar okur; farklı yerden yeniden istenmez |
| Profil adı, kapak ve fotoğraf | Profil Bilgileri | Profil kartında aynı kayıtlar |
| Branş ve sportif seviye | Sportif / Uzmanlık / Faaliyet Bilgileri → Spor Branşları | Profil kartında sadece okunur, doğrudan geçiş vardır |
| Meslek, görev ve unvan | Kişi: Eğitim Bilgileri → Meslek ve Çalışma; Eğitmen: Meslek Bilgileri → Mesleki Kimlik; Kurum: Kurum Bilgileri → Kurum Faaliyet ve Meslek | Profil kartında okunur; düzenlemek için doğru sayfaya yönlenir |
| Lisans, diploma, antrenörlük/kurumsal belge ve QR kod | Profil türünün aşağıdaki **tek belge sayfası** | Doğrulama Durumu salt okunur kayıt görünümü |
| İletişim, WhatsApp ve sosyal ağ | İletişim Bilgileri → İletişim ve Bağlantılar | Özet/ziyaretçi gizlilik kurallarına bağlı |
| Konum, ev/iş/tesis ve paylaşım | Konum Bilgileri → Temel Konum | Profil ve Kurslar'a merkezî il/ilçe/mahalle |
| Fatura ve tahsilat | Fatura Bilgileri / Ödeme Tercihleri | Satış/finans işlem özetlerinden okunur |
| Slogan ve kısa açıklama | Profil Bilgileri → Tanıtım / Beni Tanıyın düzenleyicisi | Başka tekrar eden editör açılmaz |

### Klasör sadeleştirme

- **Bireysel / Sporcu:** 14 → **13** klasör. `Belgeler ve Doğrulama` kaldırıldı; `Eğitim Bilgileri → Sertifikalar` birleşik belge formunu açıyor. `Eğitim Bilgileri → Doğrulama Durumu` salt okunur. `Kulüp Bilgileri → Lisans Bilgileri` ikinci belge formu olmaktan çıkarıldı; varsa eski lisans bilgileri belge kaydına aktarılıyor.
- **Eğitmen / Antrenör:** 16 → **15** klasör. Eski **06. Belgeler ve Doğrulama** kaldırıldı. Eski 10. `Eğitim ve Sertifikalar` içerik olarak korundu (otomatik numaralandırmada artık 09. sırada): `Antrenörlük Belgeleri` aynı çoklu belge kaynağını kullanıyor; QR/kod ve ön kontrol kaydetme alanında. `Uzmanlık Bilgileri`nde kademe bir kez, belge kayıtlarından okunuyor. Meslek ve Deneyim alanlarındaki bazı tekrarlar kaldırıldı.
- **İşletme / Kurum:** 17 → **16** klasör. Belge kayıtları `Kurum Bilgileri → Kurumsal Belgeler` içinde. `Kurum Faaliyet ve Meslek Bilgileri` faaliyet türünün tek giriş yeri; `Kurumsal Kimlik` yeniden kurum türü istemiyor.
- Eğitmen ve kurum finans klasörlerindeki aynı Fatura/Ödeme işlemlerini açan eski ara sayfalar kaldırıldı; işlevli iki sayfa korundu.

### Meslek / görev seçimi

Aynı formda profil türüne uygun roller listelenir. Örnekler: sporcu, veli/vasi, beden eğitimi öğretmeni, antrenör, eğitmen, hakem, taraftar, spor gazetecisi, kulüp yöneticisi, fizyoterapist, spor hekimi, diyetisyen, kondisyoner, performans analisti, spor psikoloğu, organizatör, sporcu temsilcisi, gönüllü; kurumlarda kulüp, okul, akademi, tesis, federasyon, rehabilitasyon ve medya. `Diğer` seçimi serbest yazı içindir. Seçilen rolün alanları açılır, diğer alanlar gizlenir; rol değişikliği eski role ait bilgileri silmez. Bu serbest rol beyanı, belgeli meslek statüsü veya sistem yetkisi oluşturmaz.

### Belge işleyişi

Belge Türü → Kaynağı → Branş → Kademe/Sınıf → Belge Tarihi → Sayı/Numara → Veren Kurum → Geçerlilik → Sahip → Kapsam → Açıklama → (isteğe bağlı dosya) → **QR Görseli / Barkod-Doğrulama Kodu** → Kaydet ve Ön Kontrol. QR okunursa kodu alana getirme denemesi yapılır; tarayıcı desteği yoksa manuel giriş kullanılır. Resmî sistem onayı olmayan sonuçlara yeşil doğrulama tiki verilmez. Eklenen görsel/PDF kalıcı profile kaydedilmez.

### Mevcut kayıt ve uyumluluk

Eski `spDocuments` dizisi korunur. Daha eski 06. klasör alanları ile Eğitmen/Antrenör `Antrenörlük Belgeleri`ndeki bazı eski düz metin alanları, belge listesi ilk kez oluşturuluyorsa tek belge kaydına alınır; sporcu lisansı/sertifika notlarında da aynı kural uygulanır. Belge listesi zaten varsa/silinmişse eski girişler otomatik tekrar oluşturulmaz. Önceki rol notları ve bazı tanıtım kayıtları silinmez. `localStorage` anahtarı değiştirilmedi.

### Deneme ve teknik sınırlar

- JavaScript sözdizimi ve tarayıcı hatasız açılış kontrolü.
- Üç profil türünde klasör sayısı ve alt sayfa eşleşmesi.
- Hakem → Fizyoterapist rol değişimi; eski role ait verilerin saklanması.
- Spor Gazetecisi ve Spor Akademisi seçimleri, düzenleme-kaydetme ve kaynaklara yansıma.
- Profil Kartı'nda başka meslek/branş için ikinci editör olmaması.
- Belge formu QR, manuel kod, önceki belge kayıtlarının okunması ve doğrulama durumu.
- Gerçek Acode/Android cihaz testi ve canlı sunucu yetkilendirme testi bu yerel tarayıcı ortamında yapılmadı.

### Bilerek açık bırakılan konular

1. Meslek seçen kişi için doğrulanmış lisans/ünvan yetkisi **resmî belge kaynağı ve sunucu doğrulaması olmadan** verilmez.
2. SporNRD demo hesabının seçilen türü sabittir. Gerçek hizmet sağlayıcı yetkileri, sözleşme ve mesleki yeterlilik kontrolleri ayrıca uygulanmalıdır.
3. Tüm alt sayfalarda otomatik yönlendirmeye konu olmayan serbest anlatım alanları, farklı amaç taşıyabileceklerinden veri kaybını önlemek için korunmuştur; canlı veri sözlüğü ve kişisel veri envanteri hazırlanırken ayrıca gözden geçirilmelidir.
4. Özel belge ve kimlik verilerinin yerel depoda tutulması canlı sistem için uygun değildir. 

### Mevzuat doğrulama referansları

- GSB Antrenör Eğitim Yönetmeliği: https://sporegitim.gsb.gov.tr/Sayfalar/2873/2859/antrenor-egitim-yonetmeligi.aspx
- GSB Antrenör Eğitim Sistemi: https://sporegitim.gsb.gov.tr/PublicBirim/Edit/images/SGMBASKANLIK/1001/SPORCU%20E%C4%9E%C4T%C4%B0M%20MERKEZLER%C4%B0/Antrenor-Egitim-Sistemi.pdf
- e-Devlet Barkodlu Belge Doğrulama: https://www.turkiye.gov.tr/belge-dogrulama

Bu dosya bir geliştirme ve test envanteridir; resmî mevzuat uygunluk/sertifika kararı değildir.
