import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
const path = new URL('../',import.meta.url);
const read = p => readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('SporNRD shell remains three-tab and shared purple/yellow palette',()=>{
  const css=read('css/style.css'), html=read('index.html');
  assert.match(css,/\.top-header, \.bottom-navigation\s*\{/);
  assert.match(css,/--sp-shell-accent:\s*#ffd52a/);
  for(const label of ['Kategoriler','Ana Sayfa','Profil'])assert.ok(html.includes(label));
  assert.ok(html.includes('js/runtime-config.js'));
});
test('Original V7.10.64 is byte-for-byte preserved',()=>{
  const h=createHash('sha256').update(readFileSync(new URL('../moduller/profil-v7-10-64/orijinal_V7_10_64_DEGISTIRILMEDI.html',import.meta.url))).digest('hex');
  assert.equal(h,'9310de27cb1e9e27aea4172ebecfe271254f71acfe7a48e97011555ffb6fbe14');
});
test('Published build never contains D1, Worker, or secret files',()=>{
  assert.ok(existsSync(new URL('../dist/index.html',import.meta.url)));
  for(const x of ['worker','migrations','services','.dev.vars','tests'])assert.ok(!existsSync(new URL('../dist/'+x,import.meta.url)));
  assert.match(read('dist/js/runtime-config.js'),/"enabled": false/);
});
