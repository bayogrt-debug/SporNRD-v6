/* SporNRD unified shell v2 — V7.10.64 compatibility bridge.
   The original app JS remains intact; we trigger only existing delegated actions.
   This is a local prototype bridge, not an authentication or payment backend. */
(()=>{
  'use strict';
  const PFX='SPNRD_V2_';
  const allowedViews=Object.freeze({
    profile:{action:'navigate',page:'profile'},
    course:{action:'open-section',category:'Kurs'},
    orders:{action:'navigate',page:'orders'},
    favorites:{action:'navigate',page:'favorites'},
    provider:{action:'navigate',page:'provider'},
    reports:{action:'navigate',page:'reports'},
    sporwin:{action:'sporwin-plan-open'},
    home:{action:'go-home'},
    account:{action:'navigate',page:'account-hub'}
  });
  const sameOrigin=(event)=>{
    if(window.parent===window || event.source!==window.parent)return false;
    // Prevent a different-origin embedding site from driving the user's local app.
    if(location.protocol==='http:' || location.protocol==='https:')return event.origin===location.origin;
    return false;
  };
  const notify=(type,payload={})=>{
    if(window.parent===window || !/^https?:$/.test(location.protocol))return;
    window.parent.postMessage({type:PFX+type,...payload},location.origin);
  };
  function trigger(view){
    const config=Object.prototype.hasOwnProperty.call(allowedViews,view)?allowedViews[view]:null;if(!config)return false;
    // The click listener in the preserved V7.10.64 app reads data-action / data-page / data-category.
    const el=document.createElement('button');el.type='button';el.hidden=true;
    for(const [key,val] of Object.entries(config))el.dataset[key]=val;
    document.body.appendChild(el);
    el.click();el.remove();
    notify('ROUTED',{view});
    return true;
  }
  function embeddingStyle(){
    if(document.getElementById('spornrd-unified-iframe-style'))return;
    const style=document.createElement('style');style.id='spornrd-unified-iframe-style';
    style.textContent=`.topbar, #bottomNav{display:none!important}
      .app-shell{min-height:100dvh!important}
      .page-content{padding-top:9px!important;padding-bottom:24px!important}
      #modalRoot .modal{max-width:100vw!important}`;
    document.head.appendChild(style);
  }
  window.addEventListener('message',event=>{
    if(!sameOrigin(event)||typeof event.data!=='object'||event.data===null)return;
    if(event.data.type===PFX+'NAVIGATE')trigger(String(event.data.view||''));
    if(event.data.type===PFX+'PING')notify('READY',{version:'7.10.64'});
  });
  embeddingStyle();
  // Only expose parent navigation. Do not echo secrets, email, phone, passwords or full localStorage records.
  notify('READY',{version:'7.10.64'});
})();
