/* Generated safe default for local Acode use. Cloudflare Pages build overwrites this public-only config. */
window.SPORNRD_RUNTIME_CONFIG = {
  feedApiBaseUrl: "https://spornrd-v6.bayogrt.workers.dev",
  cloudPilot: { enabled: false, apiBaseUrl: "", turnstileSiteKey: "" }
};
