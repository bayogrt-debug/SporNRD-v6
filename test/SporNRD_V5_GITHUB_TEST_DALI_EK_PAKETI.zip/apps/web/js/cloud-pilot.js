/* SporNRD V3 cloud pilot: isolated central account API client.
 * No tokens, passwords or secrets are persisted in localStorage/IndexedDB.
 * Existing Acode V7.10.64 remains a separate local prototype until audited migration.
 */
(()=>{
  'use strict';
  const cfg=window.SPORNRD_CONFIG?.cloudPilot||{};
  const page=document.getElementById('cloudPage'),panel=document.getElementById('cloudPanel');
  if(!page||!panel)return;
  let bearer='',me=null,turnstileToken='',pilotStatus=null,busy=false;
  let mySaved=[],courses=[],applications=[],ownerApplications=[];
  const h=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const roleName=r=>({athlete:'Bireysel / Sporcu',coach:'Eğitmen / Antrenör',business:'İşletme / Kurum'})[r]||r;
  function msg(value,kind='note'){
    const el=document.getElementById('cloudMessage');
    if(el){el.textContent=value;el.dataset.kind=kind;}
  }
  async function request(path,options={}) {
    if(!cfg.enabled)throw Error('Merkezi sistem henüz etkinleştirilmedi.');
    const controller=new AbortController(),abort=setTimeout(()=>controller.abort(),18000);
    try {
      const res=await fetch(`${String(cfg.apiBaseUrl||'').replace(/\/$/,'')}/api/v1${path}`,{
        method:options.method||'GET',headers:{'Accept':'application/json',...(options.body?{'Content-Type':'application/json'}:{}),...(bearer?{'Authorization':`Bearer ${bearer}`}:{})},
        ...(options.body?{body:JSON.stringify(options.body)}:{}),signal:controller.signal,cache:'no-store'
      });
      let data={};try{data=await res.json()}catch{}
      if(!res.ok||data.ok===false)throw Error(data.error||'İşlem yapılamadı.');
      return data;
    }finally{clearTimeout(abort)}
  }
  const input=(name,label,type='text',value='',extra='')=>`<label class="cp-field">${h(label)}<input name="${h(name)}" type="${h(type)}" value="${h(value)}" ${extra}></label>`;
  const callout=`<p class="cp-caution">🧪 <strong>Pilot test:</strong> Buradaki hesap, kurs ve başvurular gerçek kayıt/satış değildir. Acode V7.10.64 kayıtları otomatik taşınmaz. Test yalnızca 18 yaş ve üzeri kişiler içindir.</p>`;
  function showSetup(){
    panel.innerHTML=`${callout}<div class="cp-card"><h3>Merkezi hesap kurulumu bekleniyor</h3>
      <p>Cloudflare D1 veritabanı, Turnstile ve izin verilen alan adları ayarlanıp test Worker yayımlanınca burada giriş ve kayıt açılacak.</p>
      <p>Şimdilik V7.10.64 profil ve kurs sistemi yerel prototip olarak çalışmaya devam eder.</p></div>`;
  }
  function showLogin(){
    if(!cfg.enabled){showSetup();return}
    panel.innerHTML=`${callout}
      <div class="cp-card"><h3>Merkezi hesabına giriş yap</h3><form id="cpLoginForm" class="cp-form">
      ${input('email','E-posta','email','', 'autocomplete="email" required')}
      ${input('password','Şifre','password','', 'autocomplete="current-password" minlength="12" required')}
      <button class="cp-primary" type="submit">Giriş Yap</button></form></div>
      <div class="cp-card"><h3>Yeni pilot hesap oluştur</h3><form id="cpRegisterForm" class="cp-form">
      ${input('displayName','Ad Soyad','text','', 'maxlength="80" autocomplete="name" required')}
      ${input('email','E-posta','email','', 'autocomplete="email" required')}
      ${input('password','Şifre (en az 12 karakter)','password','', 'minlength="12" maxlength="128" autocomplete="new-password" required')}
      <label class="cp-field">Profil Türü<select name="role" required><option value="athlete">Bireysel / Sporcu</option><option value="coach">Eğitmen / Antrenör</option><option value="business">İşletme / Kurum</option></select></label>
      <label class="cp-check"><input name="adultConfirmed" type="checkbox" required> 18 yaş ve üzerindeyim; pilot test koşullarını kabul ediyorum.</label>
      <div id="cpTurnstile" class="cp-turnstile"></div>
      <button class="cp-primary" type="submit">Pilot Hesap Oluştur</button></form></div>`;
    if(cfg.turnstileSiteKey){setupTurnstile()}
    else document.getElementById('cpTurnstile').textContent='Güvenlik doğrulama anahtarı yapılandırılmadı; kayıt henüz açılamaz.';
  }
  function setupTurnstile(){
    const mount=()=>{
      const el=document.getElementById('cpTurnstile');
      if(el&&!el.dataset.rendered&&window.turnstile){
        window.turnstile.render(el,{sitekey:cfg.turnstileSiteKey,callback:token=>{turnstileToken=token},'expired-callback':()=>{turnstileToken=''}});
        el.dataset.rendered='true';
      }
    };
    if(window.turnstile){mount();return}
    if(document.querySelector('[data-cloud-turnstile]'))return;
    const s=document.createElement('script');s.src='https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';s.async=true;s.defer=true;s.dataset.cloudTurnstile='true';s.onload=mount;document.head.append(s);
  }
  async function refreshData(){
    if(!me)return;
    const [saved,allCourses,apps]=await Promise.all([request('/saved-posts'),request('/courses'),request('/applications')]);
    mySaved=saved.items||[];courses=allCourses.items||[];applications=apps.items||[];
    ownerApplications=['coach','business'].includes(me.role) ? (await request('/owner/applications')).items||[] : [];
  }
  function profileForm(){return `<form id="cpProfileForm" class="cp-form">
    ${input('displayName','Ad Soyad','text',me.displayName,'required maxlength="80"')}
    ${input('city','İl','text',me.city,'maxlength="100"')}
    ${input('district','İlçe','text',me.district,'maxlength="100"')}
    ${input('title','Unvan','text',me.title,'maxlength="100"')}
    <label class="cp-field">Kısa Açıklama<textarea name="bio" maxlength="1500" rows="3">${h(me.bio)}</textarea></label>
    <button type="submit" class="cp-primary">Bilgileri Kaydet</button>
    </form>`}
  function courseForm(){
    if(!['coach','business'].includes(me.role))return '';
    return `<div class="cp-card"><h3>Deneme kursu oluştur</h3><p>Buradan eklenen kurs yalnız pilot/test kursu olarak görünür.</p><form id="cpCourseForm" class="cp-form">
      ${input('name','Kurs adı','text','','required maxlength="140"')}${input('branch','Branş','text','','required maxlength="100"')}
      ${input('city','İl','text',me.city,'maxlength="80"')}${input('district','İlçe','text',me.district,'maxlength="80"')}
      ${input('capacity','Kontenjan (test)','number','10','min="1" max="1000" required')}
      ${input('startAt','Başlangıç tarihi (isteğe bağlı)','date')}
      <label class="cp-field">Açıklama<textarea name="description" maxlength="900" rows="2"></textarea></label>
      <button class="cp-primary" type="submit">Pilot Kurs Ekle</button></form></div>`;
  }
  function courseList(){return `<div class="cp-card"><h3>Merkezi pilot kurslar</h3><p>Ön kayıt yalnız test talebidir; kontenjan ayrılmaz ve tahsilat yapılmaz.</p>
    ${courses.length?courses.map(c=>`<div class="cp-item"><strong>${h(c.name)}</strong><small>${h(c.branch)} · ${h([c.city,c.district].filter(Boolean).join(' / '))} · ${h(c.providerName)}</small>
      <small>Test kontenjanı: ${h(c.capacity)}${c.startAt?' · '+h(c.startAt):''}</small>
      ${me.role==='athlete'?`<button type="button" class="cp-mini" data-cp-apply="${h(c.id)}">Test Ön Kayıt Talebi</button>`:''}</div>`).join(''):'<p>Henüz pilot kurs oluşturulmadı.</p>'}</div>`}
  function renderDashboard(){
    panel.innerHTML=`${callout}<div class="cp-card"><div class="cp-head"><div><h3>${h(me.displayName)}</h3><p>${h(roleName(me.role))} · ${h(me.email)}</p></div><button type="button" id="cpLogout">Çıkış</button></div>
    <small>E-posta doğrulaması: ${me.emailVerified?'tamamlandı':'yapılmadı (pilot)'}. Oturum yalnızca bu açık sayfada tutulur.</small></div>
    <div class="cp-card"><h3>Hesap ve Profil Bilgilerim</h3>${profileForm()}</div>
    ${courseForm()}${courseList()}
    ${['coach','business'].includes(me.role)?`<div class="cp-card"><h3>Kurslarıma gelen test talepleri</h3>
    ${ownerApplications.length?ownerApplications.map(a=>`<div class="cp-item"><strong>${h(a.courseName)} · ${h(a.applicantName)}</strong><small>${h(a.status)} · ${h(a.createdAt)}</small></div>`).join(''):'<p>Gelen test başvurusu bulunmuyor.</p>'}</div>`:''}
    <div class="cp-card"><h3>Ön kayıt taleplerim</h3>
    ${applications.length?applications.map(a=>`<div class="cp-item"><strong>${h(a.courseName)}</strong><small>${h(a.status)} · ${h(a.createdAt)}</small>${a.status==='pending'?`<button type="button" class="cp-mini" data-cp-withdraw="${h(a.id)}">Talebimi Geri Çek</button>`:''}</div>`).join(''):'<p>Henüz pilot başvuru bulunmuyor.</p>'}</div>
    <div class="cp-card"><h3>Bulutta kaydedilen haberler</h3>
    ${mySaved.length?mySaved.map(p=>`<div class="cp-item"><strong>${h(p.title||p.postId)}</strong><small>Kaynak: ${h(p.sourceId)}</small><button type="button" class="cp-mini" data-cp-unsave="${h(encodeURIComponent(p.postId))}">Kaldır</button></div>`).join(''):'<p>Bulutta kaydedilen haber bulunmuyor.</p>'}</div>
    <div class="cp-card"><h3>Hesabı Sil</h3><p>Bu işlem pilot hesap ve ona bağlı test verilerini kalıcı olarak siler.</p>
    <form id="cpDeleteForm" class="cp-form">${input('password','Mevcut şifreniz','password','', 'required')}
    ${input('confirm','Silme onayı (SİL yazın)','text','', 'required')}
    <button type="submit" class="cp-danger">Pilot hesabı kalıcı sil</button></form></div>`;
  }
  const vals=form=>Object.fromEntries(new FormData(form).entries());
  async function onSubmit(event){
    const form=event.target;
    if(!['cpLoginForm','cpRegisterForm','cpProfileForm','cpCourseForm','cpDeleteForm'].includes(form.id))return;
    event.preventDefault();if(busy)return;busy=true;
    try{
      const data=vals(form);let result;
      if(form.id==='cpLoginForm')result=await request('/auth/login',{method:'POST',body:data});
      else if(form.id==='cpRegisterForm'){
        if(!turnstileToken)throw Error('Önce Turnstile güvenlik doğrulamasını tamamlayın.');
        result=await request('/auth/register',{method:'POST',body:{...data,adultConfirmed:data.adultConfirmed==='on',turnstileToken}});
      }
      else if(form.id==='cpProfileForm')result=await request('/me',{method:'PATCH',body:data});
      else if(form.id==='cpCourseForm')result=await request('/courses',{method:'POST',body:{...data,capacity:Number(data.capacity)}});
      else if(form.id==='cpDeleteForm'){
        if(data.confirm!=='SİL')throw Error('Onay alanına SİL yazın.');
        if(!window.confirm('Pilot hesabı ve bütün kayıtları kalıcı olarak silinsin mi?'))return;
        await request('/me',{method:'DELETE',body:data}); bearer='';me=null;showLogin();msg('Hesap silindi.','good');return;
      }
      if(['cpLoginForm','cpRegisterForm'].includes(form.id)){bearer=result.token;me=result.user;await refreshData();renderDashboard();msg('Merkezi pilot hesabında oturum açıldı.','good');}
      else {if(result.user)me=result.user;await refreshData();renderDashboard();msg(result.message||'Pilot kayıt güncellendi.','good')}
    }catch(err){msg(err.message||'İşlem başarısız.','bad')}
    finally{busy=false}
  }
  async function onClick(event){
    const t=event.target.closest('button');if(!t||busy)return;
    if(t.id==='cpLogout'){
      busy=true;try{await request('/auth/logout',{method:'POST'})}catch{}
      bearer='';me=null;busy=false;showLogin();msg('Oturum kapatıldı.','good');return;
    }
    if(t.dataset.cpApply){busy=true;try{const r=await request(`/courses/${t.dataset.cpApply}/apply`,{method:'POST'});await refreshData();renderDashboard();msg(r.message,'good')}catch(e){msg(e.message,'bad')}finally{busy=false}}
    if(t.dataset.cpWithdraw){busy=true;try{const r=await request(`/applications/${t.dataset.cpWithdraw}/withdraw`,{method:'POST'});await refreshData();renderDashboard();msg(r.message,'good')}catch(e){msg(e.message,'bad')}finally{busy=false}}
    if(t.dataset.cpUnsave){busy=true;try{await request(`/saved-posts/${t.dataset.cpUnsave}`,{method:'DELETE'});await refreshData();renderDashboard();msg('Haber buluttan kaldırıldı.','good')}catch(e){msg(e.message,'bad')}finally{busy=false}}
  }
  panel.addEventListener('submit',onSubmit);panel.addEventListener('click',onClick);
  async function onOpen(){
    if(!cfg.enabled){showSetup();return;}
    if(me){try{await refreshData();renderDashboard()}catch(err){msg(err.message,'bad')}return}
    showLogin();
  }
  async function syncSavedPost(post,isSaved){
    if(!cfg.enabled||!bearer||!me)return false;
    try {
      if(isSaved)await request('/saved-posts',{method:'POST',body:{postId:String(post.id),title:String(post.title||'').slice(0,250),sourceId:String(post.sourceId||'').slice(0,40)}});
      else await request(`/saved-posts/${encodeURIComponent(String(post.id))}`,{method:'DELETE'});
      return true;
    }catch{return false}
  }
  window.SPORNRD_CLOUD_PILOT={onOpen,syncSavedPost,isSignedIn:()=>Boolean(bearer)};
  showSetup();
})();
