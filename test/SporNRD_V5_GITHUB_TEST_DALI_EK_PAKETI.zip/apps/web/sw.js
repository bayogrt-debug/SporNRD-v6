const CACHE_NAME = "spornrd-unified-v4-20261117";
const APP_FILES = ["./", "./index.html", "./manifest.json", "./css/style.css",
  "./js/config.js", "./js/runtime-config.js", "./js/liveSources.js", "./js/learningEngine.js", "./js/app.js", "./js/cloud-pilot.js", "./js/legacy-bridge.js",
  "./assets/icons/icon.svg", "./moduller/profil-v7-10-64/index.html"];
self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_FILES)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith("spornrd-") && key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin || url.pathname.includes("/api/")) return;
  event.respondWith(fetch(event.request).then(response => {
    if (response.ok) {
      const copy=response.clone();
      event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.put(event.request,copy)));
    }
    return response;
  }).catch(() => caches.match(event.request)));
});
