/* SporNRD source registry reconstruction for the V5 ISOLATED PREVIEW only.
 * The uploaded archived Worker referenced this missing module. Source identity
 * and website values are grounded in worker/sources/tyf.js and tbf.js.
 * The source registry is deliberately never substituted into live production.
 */
export const SOURCE_REGISTRY_VERSION = '1.0-preview-v5';
const SOURCES = Object.freeze([
  Object.freeze({ id:'tyf', name:'Türkiye Yüzme Federasyonu', shortName:'TYF',
    sport:'swimming', providerType:'federation', sourceType:'FEDERASYON',
    website:'https://www.tyf.gov.tr', verified:true, enabled:true,
    trust:Object.freeze({official:true}) }),
  Object.freeze({ id:'tbf', name:'Türkiye Basketbol Federasyonu', shortName:'TBF',
    sport:'basketball', providerType:'federation', sourceType:'FEDERASYON',
    website:'https://www.tbf.org.tr', verified:true, enabled:true,
    trust:Object.freeze({official:true}) })
]);
export function getSource(id) {
  return SOURCES.find(item=>item.id===String(id||'').trim().toLowerCase())||null;
}
export function getActiveSources() {return SOURCES.filter(item=>item.enabled).map(item=>({...item,trust:{...item.trust}}));}
export function createPublicSourceInfo(source) {
  if(!source||!source.id)return null;
  return {id:source.id,name:source.name,shortName:source.shortName,sport:source.sport,
    sourceType:source.sourceType,providerType:source.providerType,
    website:source.website,verified:source.verified===true,enabled:source.enabled===true};
}
export function getPublicSources() {return getActiveSources().map(createPublicSourceInfo);}
export function validateSourceRegistry() {
  const errors=[],warnings=[],seen=new Set();
  for(const source of SOURCES){
    if(!source.id||!source.name||!source.website||!source.sport)errors.push('Eksik kaynak alanı: '+source.id);
    if(seen.has(source.id))errors.push('Tekrarlanan kaynak: '+source.id);
    seen.add(source.id);
    if(!source.enabled)warnings.push('Pasif kaynak: '+source.id);
  }
  return {ok:errors.length===0,valid:errors.length===0,errors,warnings};
}
