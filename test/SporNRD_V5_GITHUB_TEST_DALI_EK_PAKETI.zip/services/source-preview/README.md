# Kaynak API — izole test kopyası

Bu klasör, kullanıcının gönderdiği **SporNRD.zip** içindeki `worker/` klasörünün **görülebilen, eski bir kopyasıdır**. Cloudflare'da bugün çalışan `spornrd-source-api-v4` sürümüyle aynı olduğu **doğrulanmadı**.

- Test Worker adı: `spornrd-source-preview-v5`
- Üretim `spornrd-v6` veya `spornrd-source-api-v4` isimlerine **dağıtım yapılmaz**.
- Kodlar karşılaştırılıp canlı servis işlevleri doğrulanmadan üretime taşınmaz.
- Worker'ın kaynak çıktısı gerçek federasyon içerikleri ve ağ erişimine bağlıdır.

**V5 test düzeltmesi:** Arşivde çağrıldığı halde bulunmayan `core/sourceRegistry.js` TYF/TBF metadata ile oluşturuldu. 6 kategoriye geçilmiş olmasına rağmen 5 kategori bekleyen test ve kursu `events` sayan örnek beklenti, yalnız bu test kopyasında `course` olarak düzeltildi. Resmî canlı sistemde bu dosyaların karşılığı doğrulanmadı.
