import {test} from 'node:test';
import assert from 'node:assert/strict';
import worker from '../src/worker.js';
import {getActiveSources,validateSourceRegistry,getSource} from '../src/core/sourceRegistry.js';
test('TYF/TBF source registry resolves safely',()=>{
  const r=validateSourceRegistry();assert.deepEqual(r.errors,[]);
  assert.equal(getActiveSources().length,2);
  assert.equal(getSource('tyf').name,'Türkiye Yüzme Federasyonu');
  assert.equal(getSource('tbf').sport,'basketball');
});
test('Source preview worker starts without live federation requests',async()=>{
  for(const p of ['/api/health','/api/sources','/api/core-test']){
    const res=await worker.fetch(new Request('https://preview.example'+p),{});
    assert.ok(res.status<500,`HTTP ${res.status} on ${p}`);
  }
});
