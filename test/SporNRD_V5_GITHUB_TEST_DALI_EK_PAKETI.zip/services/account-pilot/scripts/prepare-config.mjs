import fs from 'node:fs';
const env=process.env;
const id=String(env.TEST_D1_DATABASE_ID||'');
const origin=String(env.TEST_SITE_ORIGIN||'').trim();
const name='spornrd-account-pilot-v5';
if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id))throw Error('TEST_D1_DATABASE_ID geçerli D1 UUID olmalı.');
let u;try{u=new URL(origin)}catch{throw Error('TEST_SITE_ORIGIN HTTPS origin olmalı.');}
if(u.origin!==origin||u.protocol!=='https:')throw Error('Tam HTTPS origin girin; yol eklemeyin.');
const cfg=JSON.parse(fs.readFileSync(new URL('../wrangler.test.example.jsonc',import.meta.url),'utf8'));
cfg.name=name; cfg.vars.ALLOWED_ORIGINS=origin;cfg.vars.TURNSTILE_HOSTNAME=u.hostname;
cfg.d1_databases[0].database_id=id;
const out=new URL('../wrangler.test.jsonc',import.meta.url);
if(fs.existsSync(out))throw Error('wrangler.test.jsonc zaten mevcut; üzerine yazılmadı.');
fs.writeFileSync(out,JSON.stringify(cfg,null,2)+'\n',{mode:0o600});
console.log('İzole account-pilot config oluşturuldu, Worker:',name);
