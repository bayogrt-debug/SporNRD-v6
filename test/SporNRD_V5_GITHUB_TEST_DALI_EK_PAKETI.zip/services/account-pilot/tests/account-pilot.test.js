import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {handleAccountApi} from '../src/api.js';
const sql=readFileSync(new URL('../migrations/0001_pilot.sql',import.meta.url),'utf8');
const db=new DatabaseSync(':memory:');db.exec(sql);
const D1={prepare(sql){const st=db.prepare(sql);return {bind(...params){return {first:async()=>st.get(...params)||null,all:async()=>({results:st.all(...params)}),run:async()=>({meta:st.run(...params)})}},first:async()=>st.get()||null,all:async()=>({results:st.all()}),run:async()=>({meta:st.run()})}}};
const env={DB:D1,PILOT_MODE:'true',ALLOWED_ORIGINS:'https://test.spor.example',TURNSTILE_SECRET:'private-test-value',TURNSTILE_HOSTNAME:'test.spor.example'};
const origFetch=globalThis.fetch;
globalThis.fetch=async(input,init)=>{
  if(String(input)==='https://challenges.cloudflare.com/turnstile/v0/siteverify')return new Response(JSON.stringify({success:true,hostname:'test.spor.example'}));
  return origFetch(input,init);
};
const url=p=>`https://worker.spor.example/api/v1${p}`;
async function call(p,method='GET',body,token,origin='https://test.spor.example'){
  const req=new Request(url(p),{method,headers:{...(origin?{Origin:origin}:{}),...(token?{Authorization:'Bearer '+token}:{}),...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});
  const res=await handleAccountApi(req,env);const json=res.status!==204?await res.json():null;
  return {status:res.status,json,headers:res.headers};
}
let student='',coach='',courseId='';
test('Preflight only for configured origin, rejects other sites',async()=>{
  const ok=await call('/me','OPTIONS');assert.equal(ok.status,204);assert.equal(ok.headers.get('Access-Control-Allow-Origin'),'https://test.spor.example');
  const deny=await call('/me','GET',null,null,'https://attacker.example');assert.equal(deny.status,403);assert.equal(deny.headers.get('Access-Control-Allow-Origin'),null);
});
test('Registers isolated adult pilot accounts, no passwords returned',async()=>{
  const one=await call('/auth/register','POST',{displayName:'Test Sporcu',email:'athlete@example.org',password:'SporNRDdenemePass12',role:'athlete',turnstileToken:'testToken',adultConfirmed:true});
  assert.equal(one.status,201);assert.equal(one.json.user.role,'athlete');assert.equal(one.json.user.emailVerified,false);student=one.json.token;
  assert.equal(one.json.user.password_hash,undefined);
  const second=await call('/auth/register','POST',{displayName:'Test Antrenör',email:'coach@example.org',password:'SporNRDdenemePass12',role:'coach',turnstileToken:'testToken',adultConfirmed:true});
  assert.equal(second.status,201);coach=second.json.token;
  const minor=await call('/auth/register','POST',{displayName:'Çocuk',email:'minor@example.org',password:'SporNRDdenemePass12',role:'athlete',turnstileToken:'testToken',adultConfirmed:false});
  assert.equal(minor.status,400);
});
test('Authentication and profile write separated between users',async()=>{
  const wrong=await call('/auth/login','POST',{email:'athlete@example.org',password:'NotTheSamePassword'});assert.equal(wrong.status,401);
  const r=await call('/me','PATCH',{displayName:'Sporcu Adı',city:'Aydın',district:'Efeler',title:'Sporcu',bio:'Deneme'},student);
  assert.equal(r.status,200);assert.equal(r.json.user.city,'Aydın');
  const coachMe=await call('/me','GET',null,coach);assert.equal(coachMe.json.user.city,'');
  assert.equal((await call('/me')).status,401);
});
test('Saves are user-owned and upserted, not visible to other user',async()=>{
  assert.equal((await call('/saved-posts','POST',{postId:'tyf-p-1',sourceId:'tyf',title:'TYF Duyurusu'},student)).status,200);
  assert.equal((await call('/saved-posts','POST',{postId:'tyf-p-1',sourceId:'tyf',title:'Yeni Başlık'},student)).status,200);
  const own=await call('/saved-posts','GET',null,student);assert.equal(own.json.items.length,1);assert.equal(own.json.items[0].title,'Yeni Başlık');
  const other=await call('/saved-posts','GET',null,coach);assert.equal(other.json.items.length,0);
});
test('Role authorization; course pilot apply and duplicate rejection',async()=>{
  assert.equal((await call('/courses','POST',{name:'Yüzme',branch:'Yüzme',capacity:10},student)).status,403);
  const r=await call('/courses','POST',{name:'Test Yüzme Grubu',branch:'Yüzme',capacity:10,city:'İzmir'},coach);
  assert.equal(r.status,201);courseId=r.json.id;
  assert.equal((await call('/courses')).json.items.length,1);
  assert.equal((await call(`/courses/${courseId}/apply`,'POST',{},coach)).status,403);
  const applied=await call(`/courses/${courseId}/apply`,'POST',{},student);assert.equal(applied.status,201);assert.equal(applied.json.status,'pending');
  assert.equal((await call(`/courses/${courseId}/apply`,'POST',{},student)).status,409);
  assert.equal((await call('/applications','GET',null,student)).json.items.length,1);
  assert.equal((await call('/applications','GET',null,coach)).json.items.length,0);
  assert.equal((await call('/owner/applications','GET',null,student)).status,403);
  const ownerApps=await call('/owner/applications','GET',null,coach);assert.equal(ownerApps.json.items.length,1);assert.equal(ownerApps.json.items[0].applicantName,'Sporcu Adı');
  assert.equal((await call(`/applications/${ownerApps.json.items[0].id}/withdraw`,'POST',{},coach)).status,404);
  assert.equal((await call(`/applications/${ownerApps.json.items[0].id}/withdraw`,'POST',{},student)).status,200);
  assert.equal((await call('/applications','GET',null,student)).json.items[0].status,'withdrawn');
});
test('Logout revokes bearer token; password required for deletion',async()=>{
  assert.equal((await call('/auth/logout','POST',{},student)).status,200);
  assert.equal((await call('/me','GET',null,student)).status,401);
  const re=await call('/auth/login','POST',{email:'athlete@example.org',password:'SporNRDdenemePass12'});assert.equal(re.status,200);student=re.json.token;
  assert.equal((await call('/me','DELETE',{confirm:'SİL',password:'IncorrectPassword123'},student)).status,401);
  assert.equal((await call('/me','DELETE',{confirm:'SİL',password:'SporNRDdenemePass12'},student)).status,200);
  assert.equal((await call('/me','GET',null,student)).status,401);
});
test('Pilot routes fail closed without DB and with PILOT_MODE off',async()=>{
  const backup=env.DB;env.DB=undefined;
  assert.equal((await call('/me')).status,503);env.DB=backup;
  env.PILOT_MODE='false';
  assert.equal((await call('/courses')).status,403);
  env.PILOT_MODE='true';
});
