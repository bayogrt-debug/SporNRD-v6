/* SporNRD central account PILOT v3.
 * Isolated from existing federation feed. No payments, real enrollment, staff
 * verification, child accounts, or migration of legacy localStorage data.
 * Fail-closed configuration: D1 + explicit origins + Turnstile for registration.
 */
const enc = new TextEncoder();
const NOW = () => new Date().toISOString();
const PILOT = env => env?.PILOT_MODE === 'true';
class ApiError extends Error { constructor(status,code,message) { super(message); this.status=status; this.code=code; } }
const bad=(message='Geçersiz istek.')=>{throw new ApiError(400,'invalid_input',message)};
const randomHex=(bytes=24)=>Array.from(crypto.getRandomValues(new Uint8Array(bytes)),n=>n.toString(16).padStart(2,'0')).join('');
const sha256=async text=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(text))),n=>n.toString(16).padStart(2,'0')).join('');
async function passwordHash(password,salt) {
  const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);
  const data=await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:enc.encode(salt),iterations:260000},key,256);
  return Array.from(new Uint8Array(data),n=>n.toString(16).padStart(2,'0')).join('');
}
function constantTime(a,b) {let diff=a.length^b.length; for(let i=0;i<Math.max(a.length,b.length);i++) diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0); return diff===0;}
function origins(env) {return String(env?.ALLOWED_ORIGINS||'').split(',').map(v=>v.trim()).filter(Boolean)}
function corsHeaders(request,env) {
  const o=request.headers.get('Origin'), allow=origins(env);
  if(!o)return {'Vary':'Origin'};
  if(!allow.includes(o))throw new ApiError(403,'origin_denied','Bu kaynağa erişim izni bulunmuyor.');
  return {'Access-Control-Allow-Origin':o,'Access-Control-Allow-Methods':'GET, POST, PATCH, DELETE, OPTIONS','Access-Control-Allow-Headers':'Authorization, Content-Type','Access-Control-Max-Age':'600','Vary':'Origin'};
}
function reply(data,status=200,headers={}) {
  return new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}})
}
async function parseBody(request) {
  const text=await request.text();
  if(text.length>12000)throw new ApiError(413,'body_too_large','İstek çok büyük.');
  try {const b=JSON.parse(text||'{}');if(!b||Array.isArray(b)||typeof b!=='object')bad();return b} catch(e){if(e instanceof ApiError)throw e;bad('JSON okunamadı.')}
}
function field(value,max=100,required=false) {
  if(typeof value!=='string'){if(required)bad('Zorunlu bilgi eksik.');return ''}
  const val=value.trim().replace(/\s+/g,' ');
  if(val.length>max||(required&&!val))bad('Alan uzunluğu veya değeri geçersiz.');
  return val;
}
function emailField(v) {
  const v2=field(v,254,true).toLowerCase();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v2))bad('E-posta adresi geçersiz.');
  return v2;
}
function passwordField(v) {
  if(typeof v!=='string'||v.length<12||v.length>128)bad('Şifre 12–128 karakter olmalıdır.');
  return v;
}
const publicUser=u=>({id:u.id,email:u.email,displayName:u.display_name,role:u.role,city:u.city,district:u.district,title:u.title,bio:u.bio,emailVerified:Boolean(u.email_verified),pilot:true});
async function findAuth(request,env) {
  const bearer=request.headers.get('Authorization')||'';
  const match=/^Bearer ([0-9a-f]{64})$/i.exec(bearer);
  if(!match)throw new ApiError(401,'login_required','Giriş yapmalısınız.');
  const hash=await sha256(match[1]);
  const u=await env.DB.prepare(`SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.revoked_at IS NULL AND s.expires_at>?`).bind(hash,NOW()).first();
  if(!u)throw new ApiError(401,'session_expired','Oturum sona erdi. Yeniden giriş yapın.');
  return {user:u,hash};
}
async function newSession(env,user) {
  const token=randomHex(32), tokenHash=await sha256(token), created=NOW(), expires=new Date(Date.now()+12*3600000).toISOString();
  await env.DB.prepare(`INSERT INTO sessions (token_hash,user_id,created_at,expires_at) VALUES (?,?,?,?)`).bind(tokenHash,user.id,created,expires).run();
  return {token,expiresAt:expires,user:publicUser(user)};
}
async function verifyTurnstile(env,body,request) {
  if(!env.TURNSTILE_SECRET)throw new ApiError(503,'captcha_not_configured','Kayıt doğrulaması henüz kurulmadı.');
  const token=field(body.turnstileToken,2048,true);
  let success=false;
  try {
    const form=new FormData();form.set('secret',String(env.TURNSTILE_SECRET));form.set('response',token);
    const r=await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',body:form});
    const verification=await r.json();
    success=verification.success===true && Boolean(env.TURNSTILE_HOSTNAME) && verification.hostname===String(env.TURNSTILE_HOSTNAME);
  }catch{/* no bypass */}
  if(!success)throw new ApiError(403,'captcha_failed','Güvenlik doğrulaması başarısız.');
}
async function loginAllowed(env,email) {
  const k=await sha256(email);const r=await env.DB.prepare('SELECT * FROM auth_throttle WHERE email_key=?').bind(k).first();
  if(r&&r.blocked_until>Date.now())throw new ApiError(429,'too_many_attempts','Bir süre sonra tekrar deneyin.');
}
async function recordFailure(env,email) {
  const k=await sha256(email),ts=Date.now();
  const r=await env.DB.prepare('SELECT * FROM auth_throttle WHERE email_key=?').bind(k).first();
  const newWindow=!r||ts-r.window_started_at>900000; const fails=newWindow?1:r.fails+1;
  await env.DB.prepare(`INSERT INTO auth_throttle(email_key,fails,window_started_at,blocked_until) VALUES(?,?,?,?) ON CONFLICT(email_key) DO UPDATE SET fails=excluded.fails, window_started_at=excluded.window_started_at,blocked_until=excluded.blocked_until`).bind(k,fails,newWindow?ts:r.window_started_at,fails>=5?ts+900000:0).run();
}
async function loginWithPassword(env,body) {
  const email=emailField(body.email),password=passwordField(body.password);
  await loginAllowed(env,email);
  const user=await env.DB.prepare('SELECT * FROM users WHERE email=?').bind(email).first();
  // Use a fixed-format dummy hash operation to reduce account enumeration timing.
  const salt=user?.password_salt||'00000000000000000000000000000000';
  const hash=await passwordHash(password,salt);
  if(!user||!constantTime(hash,user.password_hash)){
    await recordFailure(env,email);
    throw new ApiError(401,'invalid_credentials','E-posta veya şifre hatalı.');
  }
  await env.DB.prepare('DELETE FROM auth_throttle WHERE email_key=?').bind(await sha256(email)).run();
  return user;
}
async function requirePilot(env) {if(!PILOT(env))throw new ApiError(403,'pilot_off','Deneme işlemleri şu anda kapalı.');}
async function handle(request,env,path) {
  const method=request.method;
  if(path==='/api/v1/status'&&method==='GET')return reply({ok:true,configured:!!env.DB,pilot:PILOT(env),turnstileRequired:true,version:'3-pilot'});
  if(!env.DB)throw new ApiError(503,'database_not_configured','Veritabanı kurulmamış.');
  if(path==='/api/v1/auth/register'&&method==='POST'){
    await requirePilot(env);
    const b=await parseBody(request);
    const email=emailField(b.email),name=field(b.displayName,80,true),password=passwordField(b.password);
    if(b.adultConfirmed!==true)bad('Bu pilot yalnızca 18 yaş ve üzeri kullanıcıların testine açıktır.');
    if(!['athlete','coach','business'].includes(b.role))bad('Profil türünü seçin.');
    await verifyTurnstile(env,b,request);
    const salt=randomHex(16),hash=await passwordHash(password,salt),id=crypto.randomUUID(),now=NOW();
    try {await env.DB.prepare(`INSERT INTO users(id,email,password_salt,password_hash,display_name,role,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)`).bind(id,email,salt,hash,name,b.role,now,now).run();}
    catch {throw new ApiError(409,'email_exists','Bu e-posta ile kayıt oluşturulamıyor.');}
    const user=await env.DB.prepare('SELECT * FROM users WHERE id=?').bind(id).first();
    return reply({ok:true,...await newSession(env,user),message:'Pilot hesabı oluşturuldu. E-posta resmen doğrulanmadı.'},201);
  }
  if(path==='/api/v1/auth/login'&&method==='POST'){
    await requirePilot(env);
    const user=await loginWithPassword(env,await parseBody(request));
    return reply({ok:true,...await newSession(env,user)});
  }
  const mLogout=path==='/api/v1/auth/logout'&&method==='POST';
  if(mLogout){const a=await findAuth(request,env);await env.DB.prepare('UPDATE sessions SET revoked_at=? WHERE token_hash=?').bind(NOW(),a.hash).run();return reply({ok:true});}
  if(path==='/api/v1/me'&&method==='GET'){const {user}=await findAuth(request,env);return reply({ok:true,user:publicUser(user)});}
  if(path==='/api/v1/me'&&method==='PATCH'){
    await requirePilot(env);const a=await findAuth(request,env),b=await parseBody(request);
    const displayName=field(b.displayName,80,true),city=field(b.city,100),district=field(b.district,100),title=field(b.title,100),bio=field(b.bio,1500);
    await env.DB.prepare('UPDATE users SET display_name=?,city=?,district=?,title=?,bio=?,updated_at=? WHERE id=?').bind(displayName,city,district,title,bio,NOW(),a.user.id).run();
    return reply({ok:true,user:publicUser(await env.DB.prepare('SELECT * FROM users WHERE id=?').bind(a.user.id).first())});
  }
  if(path==='/api/v1/me'&&method==='DELETE'){
    await requirePilot(env);const a=await findAuth(request,env),b=await parseBody(request);
    if(b.confirm!=='SİL')bad('Hesabı silmek için SİL yazın.');
    await loginWithPassword(env,{email:a.user.email,password:b.password});
    await env.DB.prepare('DELETE FROM users WHERE id=?').bind(a.user.id).run();
    return reply({ok:true,deleted:true});
  }
  if(path==='/api/v1/saved-posts'&&method==='GET'){
    const a=await findAuth(request,env);
    const result=await env.DB.prepare('SELECT post_id AS postId,source_id AS sourceId,title,saved_at AS savedAt FROM saved_posts WHERE user_id=? ORDER BY saved_at DESC LIMIT 250').bind(a.user.id).all();
    return reply({ok:true,items:result.results||[]});
  }
  if(path==='/api/v1/saved-posts'&&method==='POST'){
    await requirePilot(env);const a=await findAuth(request,env),b=await parseBody(request);
    const postId=field(b.postId,200,true),sourceId=field(b.sourceId,40),title=field(b.title,250);
    await env.DB.prepare(`INSERT INTO saved_posts(user_id,post_id,source_id,title,saved_at) VALUES(?,?,?,?,?) ON CONFLICT(user_id,post_id) DO UPDATE SET title=excluded.title,source_id=excluded.source_id`).bind(a.user.id,postId,sourceId,title,NOW()).run();
    return reply({ok:true});
  }
  if(path.startsWith('/api/v1/saved-posts/')&&method==='DELETE'){
    await requirePilot(env);const a=await findAuth(request,env);
    const postId=decodeURIComponent(path.slice('/api/v1/saved-posts/'.length));
    if(!postId||postId.length>200)bad();
    await env.DB.prepare('DELETE FROM saved_posts WHERE user_id=? AND post_id=?').bind(a.user.id,postId).run();
    return reply({ok:true});
  }
  if(path==='/api/v1/courses'&&method==='GET'){
    await requirePilot(env);
    const r=await env.DB.prepare(`SELECT c.id,c.name,c.branch,c.city,c.district,c.description,c.capacity,c.start_at AS startAt,c.created_at AS createdAt,u.display_name AS providerName FROM pilot_courses c JOIN users u ON u.id=c.owner_id WHERE c.status='pilot' ORDER BY c.created_at DESC LIMIT 100`).all();
    return reply({ok:true,pilot:true,items:r.results||[]});
  }
  if(path==='/api/v1/courses'&&method==='POST'){
    await requirePilot(env);const a=await findAuth(request,env);
    if(!['coach','business'].includes(a.user.role))throw new ApiError(403,'role_denied','Yalnızca eğitmen veya kurum pilot kursu oluşturabilir.');
    const b=await parseBody(request),name=field(b.name,140,true),branch=field(b.branch,100,true),city=field(b.city,80),district=field(b.district,80),description=field(b.description,900),startAt=field(b.startAt,40);
    const capacity=Number(b.capacity);if(!Number.isInteger(capacity)||capacity<1||capacity>1000)bad('Kontenjan 1–1000 arasında olmalıdır.');
    const id=crypto.randomUUID();
    await env.DB.prepare(`INSERT INTO pilot_courses(id,owner_id,name,branch,city,district,description,capacity,start_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)`).bind(id,a.user.id,name,branch,city,district,description,capacity,startAt,NOW()).run();
    return reply({ok:true,pilot:true,id,message:'Yalnızca pilot/test kursu oluşturuldu. Gerçek satışa açık değildir.'},201);
  }
  if(path==='/api/v1/applications'&&method==='GET'){
    const a=await findAuth(request,env);
    const r=await env.DB.prepare(`SELECT a.id,a.course_id AS courseId,c.name AS courseName,a.status,a.created_at AS createdAt FROM pilot_applications a JOIN pilot_courses c ON a.course_id=c.id WHERE a.applicant_id=? ORDER BY a.created_at DESC LIMIT 100`).bind(a.user.id).all();
    return reply({ok:true,pilot:true,items:r.results||[]});
  }
  if(path==='/api/v1/owner/applications'&&method==='GET'){
    await requirePilot(env);const a=await findAuth(request,env);
    if(!['coach','business'].includes(a.user.role))throw new ApiError(403,'role_denied','Yalnızca eğitmen veya kurum başvuruları görebilir.');
    const r=await env.DB.prepare(`SELECT a.id,a.course_id AS courseId,c.name AS courseName,u.display_name AS applicantName,a.status,a.created_at AS createdAt FROM pilot_applications a JOIN pilot_courses c ON c.id=a.course_id JOIN users u ON u.id=a.applicant_id WHERE c.owner_id=? ORDER BY a.created_at DESC LIMIT 100`).bind(a.user.id).all();
    return reply({ok:true,pilot:true,items:r.results||[]});
  }
  const withdraw=/^\/api\/v1\/applications\/([0-9a-f-]{36})\/withdraw$/.exec(path);
  if(withdraw&&method==='POST'){
    await requirePilot(env);const a=await findAuth(request,env);
    const result=await env.DB.prepare(`UPDATE pilot_applications SET status='withdrawn' WHERE id=? AND applicant_id=? AND status='pending'`).bind(withdraw[1],a.user.id).run();
    if(!result.meta?.changes)throw new ApiError(404,'application_not_found','Aktif ön kayıt talebi bulunamadı.');
    return reply({ok:true,pilot:true,message:'Test ön kayıt talebi geri çekildi.'});
  }
  const apply=/^\/api\/v1\/courses\/([0-9a-f-]{36})\/apply$/.exec(path);
  if(apply&&method==='POST'){
    await requirePilot(env);const a=await findAuth(request,env);
    if(a.user.role!=='athlete')throw new ApiError(403,'role_denied','Başvuru için Bireysel/Sporcu hesabı gerekir.');
    const course=await env.DB.prepare(`SELECT id,owner_id FROM pilot_courses WHERE id=? AND status='pilot'`).bind(apply[1]).first();
    if(!course)throw new ApiError(404,'course_not_found','Kurs bulunamadı.');
    if(course.owner_id===a.user.id)bad('Kendi kursuna başvuru yapılamaz.');
    try {await env.DB.prepare(`INSERT INTO pilot_applications(id,course_id,applicant_id,created_at) VALUES(?,?,?,?)`).bind(crypto.randomUUID(),course.id,a.user.id,NOW()).run();}
    catch {throw new ApiError(409,'already_applied','Bu pilot kursuna zaten başvurdunuz.');}
    return reply({ok:true,pilot:true,status:'pending',message:'Deneme ön kayıt talebi alındı; kontenjan ayrılmadı, ödeme yapılmadı.'},201);
  }
  throw new ApiError(404,'not_found','İşlem bulunamadı.');
}
export async function handleAccountApi(request,env) {
  let headers={};
  try {
    headers=corsHeaders(request,env);
    if(request.method==='OPTIONS')return new Response(null,{status:204,headers});
    const url=new URL(request.url);
    return await handle(request,env,url.pathname.replace(/\/+$/,'')||'/').then(response=>{
      for(const [k,v] of Object.entries(headers))response.headers.set(k,v);
      return response;
    });
  }catch(err) {
    const status=err instanceof ApiError?err.status:500;
    const code=err instanceof ApiError?err.code:'internal_error';
    const message=err instanceof ApiError?err.message:'Sunucu işlemi tamamlayamadı.';
    return reply({ok:false,code,error:message},status,headers);
  }
}
