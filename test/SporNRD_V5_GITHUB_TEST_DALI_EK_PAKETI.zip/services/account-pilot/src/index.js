/* Isolated, test-only SporNRD account API (never payments/real users). */
import {handleAccountApi} from './api.js';
export default { fetch(request, env) {
  if (!new URL(request.url).pathname.startsWith('/api/v1/'))
    return new Response('Not Found', {status:404,headers:{'Cache-Control':'no-store'}});
  return handleAccountApi(request,env);
}};
