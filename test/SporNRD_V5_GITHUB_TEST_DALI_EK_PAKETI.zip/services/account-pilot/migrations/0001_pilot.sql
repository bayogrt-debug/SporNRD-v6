-- SporNRD V3 pilot: isolated tables; does not alter feed/learning tables.
-- Apply once to an isolated D1 pilot database, never a live database before review.
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL COLLATE NOCASE UNIQUE,
  password_salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('athlete','coach','business')),
  city TEXT NOT NULL DEFAULT '',
  district TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL DEFAULT '',
  bio TEXT NOT NULL DEFAULT '',
  email_verified INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  revoked_at TEXT
);
CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions(user_id);
CREATE TABLE IF NOT EXISTS auth_throttle (
  email_key TEXT PRIMARY KEY,
  fails INTEGER NOT NULL DEFAULT 0,
  window_started_at INTEGER NOT NULL DEFAULT 0,
  blocked_until INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS saved_posts (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  post_id TEXT NOT NULL,
  source_id TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL DEFAULT '',
  saved_at TEXT NOT NULL,
  PRIMARY KEY (user_id,post_id)
);
CREATE TABLE IF NOT EXISTS pilot_courses (
  id TEXT PRIMARY KEY,
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  branch TEXT NOT NULL,
  city TEXT NOT NULL DEFAULT '',
  district TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  capacity INTEGER NOT NULL CHECK(capacity BETWEEN 1 AND 1000),
  start_at TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pilot' CHECK(status IN ('pilot','draft')),
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS pilot_courses_owner_idx ON pilot_courses(owner_id);
CREATE TABLE IF NOT EXISTS pilot_applications (
  id TEXT PRIMARY KEY,
  course_id TEXT NOT NULL REFERENCES pilot_courses(id) ON DELETE CASCADE,
  applicant_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','withdrawn')),
  created_at TEXT NOT NULL,
  UNIQUE (course_id,applicant_id)
);
CREATE INDEX IF NOT EXISTS pilot_apps_user_idx ON pilot_applications(applicant_id);
CREATE INDEX IF NOT EXISTS pilot_apps_course_idx ON pilot_applications(course_id);
