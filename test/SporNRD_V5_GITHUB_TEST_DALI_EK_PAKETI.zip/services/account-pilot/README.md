# İzole D1 hesap pilotu

Yalnız 18+ **test** hesapları; e-posta doğrulama, çocuk profilleri, ödeme, resmî belge doğrulama ve tüm V7.10.64 alanlarının D1'e taşınması **yoktur**.

1. Test amaçlı D1 veritabanını Cloudflare'da ayrı oluşturun.
2. `TEST_D1_DATABASE_ID=<UUID> TEST_SITE_ORIGIN=https://preview.example.pages.dev node services/account-pilot/scripts/prepare-config.mjs`
3. `npx wrangler d1 migrations apply DB --remote --config services/account-pilot/wrangler.test.jsonc` (yalnız boş test D1)
4. `npx wrangler secret put TURNSTILE_SECRET --config services/account-pilot/wrangler.test.jsonc`
5. `npx wrangler deploy --config services/account-pilot/wrangler.test.jsonc` (yalnız test Worker)

Gerçek Cloudflare'ı etkileyen 3–5. adımları, test veritabanı doğrulanmadan çalıştırmayın. Hiçbir sırrı Git'e yazmayın.
