# SporNRD V5 — CANLI SİSTEME DOKUNMAYAN GitHub entegrasyon hazırlığı

**Kaynaklar:** Kullanıcının gönderdiği V4 ZIP, SporNRD.zip, GitHub `SporNRD-v6` kök `package.json` / `wrangler.jsonc` ekran görüntüleri. Güncel GitHub dalındaki dosyaların bayt düzeyindeki karşılığı doğrulanamadı (canlı depo bu çalışma ortamında indirilemiyor).

## Bu ZIP ne içerir?

- `apps/web/`: V4 sarı–mor arayüz, alt menü **Kategoriler · Ana Sayfa · Profil**, TYF/TBF **SporNRD Editör** profilleri, V7.10.64 ekranlarının korunan modülü.
- `services/source-preview/`: **SporNRD.zip arşivinden** bağımsız kaynak keşif testi. Canlı source-api-v4 koduyla **aynı olduğu varsayılmamalı**. Test Worker adı `spornrd-source-preview-v5`.
- `services/account-pilot/`: D1 test kayıtları, profil, haber kaydı, test kursu ve başvurular için ayrı Worker; test adı `spornrd-account-pilot-v5`.
- `.github/workflows/spornrd-v5-preview-checks.yml`: sadece test, dosya doğrulaması ve build artefaktı; canlı dağıtım yok.
- `integration-tools/verify-repo.mjs`: mevcut canlı depo `wrangler.jsonc` / `package.json` değerlerini koruma ve test hedeflerini ayrıştırma.

### Kritik koruma kuralı

Bu ZIP, **eklenebilir (add-only)** yapıdadır. Canlı GitHub `SporNRD-v6` deposundaki aşağıdaki dosya ve klasörler **ZIP'de yoktur** ve kesinlikle değiştirilmemelidir:

- `/wrangler.jsonc` (canlı `spornrd-v6`)
- `/package.json`
- `/worker/` (canlı kaynak keşif çekirdeği)

`spornrd-source-api-v4` Cloudflare projesinin `/` + `npx wrangler deploy` ayarlarının farklı kök Worker'a bağlanma riskini ortadan kaldıracak kalıcı düzeltme henüz **Cloudflare üzerinden yapılmadı**; yapılandırma onayı gelmeden otomatik deploy ayarlarını değiştirmeyin. Özellikle root `wrangler.jsonc` üzerinde toplu değişiklik **yapmayın**.

## Önerilen güvenli kurulum sırası

1. GitHub'da `bayogrt-debug/SporNRD-v6` deposunun **mevcut `main` commitini** not alın; mümkünse kod yedeği indirin.
2. `main` dalından `test/spornrd-v5-integration` isminde yeni dal açın.
3. **Yalnız bu ZIP'deki yeni klasörleri** test dalına ekleyin; `.gitignore` dosyasını mevcut olanla değiştirmeyin. Telefon üzerinden çalışıyorsanız GitHub Codespaces terminalinde ZIP'i açıp dosyaları sürükleyerek taşımak veya bilgisayardan `git` ile göndermek daha güvenlidir; GitHub web arayüzü bir ZIP'i otomatik açmaz.
4. Test dalında `node integration-tools/verify-repo.mjs` çalıştırın. **Herhangi bir hata çıkarsa dağıtım yapmayın.**
5. `node --test services/account-pilot/tests/account-pilot.test.js` ve `node --test services/source-preview/tests/core.test.mjs` ve `node apps/web/scripts/build-site.mjs` (çalışma dizini `apps/web`) ile test edin; ardından `node --test apps/web/tests/web.test.mjs`.
6. Test dalından `main`e otomatik merge/PR yapılmaz. Cloudflare Workers Builds yapılandırmasında test dalının mevcut production Workerları etkileyen otomatik deploy davranışı olup olmadığını **ayrıca kontrol edin**. Doğrulamadan test dalına push atmak bile preview build başlatabilir.
7. Ayrı bir Cloudflare Pages **test** projesinde proje kökü `apps/web`, build command `node scripts/build-site.mjs`, output directory `dist`, pilot **OFF**. Var olan `spornrd-v6` ve `spornrd-source-api-v4` Workerlarını değiştirmeyin.
8. D1 bağlanacaksa `services/account-pilot/README.md` adımlarını yalnız yeni veritabanı ve ayrı pilot Worker için uygulayın; gerçek ödeme veya canlı kullanıcı girişi yoktur.

## Neler kesinlikle hazır değil?

- Canlı GitHub deposuna push edilmedi; Cloudflare proje ayarları güncellenmedi.
- Aynı GitHub deposundaki mevcut `spornrd-source-api-v4` canlı kaynak kodu repo ekranından tamamen görülmedi.
- V7.10.64'teki tüm `localStorage` işlemleri D1'e taşınmadı.
- Gerçek e-posta doğrulama, çocuk hesapları, ödeme, iade, belge doğrulama, prod güvenliği ve Android yayın testi yok.
- API çalışan test mantığı mevcut; Cloudflare D1 bağlantısında gerçek uçtan uca test yapılmadı.

## Kaynak motorunda düzelttiğimiz test kusurları

`SporNRD.zip` ve V4 Worker kopyalarında referans verilen `worker/core/sourceRegistry.js` dosyası yoktu. **Yalnızca `services/source-preview/` içinde** TYF/TBF kaynak kimliklerine dayalı kayıt defteri tamamlandı. Eski `coreTest.js` test beklentileri altı kategori ve `course`/`swimming` sözlüğüyle uyumsuzdu; yalnız izole test kopyasında düzeltildi. `/api/health`, `/api/sources`, `/api/core-test` çevrimdışı kontrolleri artık başarıyla yanıt verebiliyor. Bu değişiklikler üretim Worker kodunu düzeltmiş sayılmaz. Gerçek federasyon okuma testleri ayrıca gerekli.

## Üretime geçiş önkoşulları

Mevcut iki Worker'ın **kod ve env binding farkları** karşılaştırılmalı; Cloudflare servis başına ayrı `root_directory` ve `wrangler` dosyası seçilmeli; HTTPS/CORS, D1, Turnstile, oturum işlemleri ve kullanıcı kabul testleri staging'de doğrulanmalı. Canlı `main` bu aşamada değiştirilmez.

**V7.10.64 SHA-256:** `9310de27cb1e9e27aea4172ebecfe271254f71acfe7a48e97011555ffb6fbe14`
